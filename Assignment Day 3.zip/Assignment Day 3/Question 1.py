#!/usr/bin/env python
# coding: utf-8

# In[ ]:


num=input("Enter the altitude: ")
int (num)
 


if num<1000:
    print("Safe to Land")
    
    elif num>1000 && num<5000:
    print("Bring Down to 1000")
    
    else:
    print("Turn Around")

