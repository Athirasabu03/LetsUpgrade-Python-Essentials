#!/usr/bin/env python
# coding: utf-8

# In[3]:


# Python program to demonstrate the  
# use of capitalize() function  
  
# capitalize() first letter of  
# string. 
name = "i am athira and i am an engineer"
  
print(name.capitalize())  
  
# demonstration of individual words  
# capitalization to generate camel case 
name1 = "i"
name2 = "am"
name3 = "athira"
name4 = "and"
name5 = "i"
name6 = "am"
name7 = "an"
name8 = "engineer"

print(name1.capitalize() +" "+ name2.capitalize()+" " 
                         + name3.capitalize()+" " +name4.capitalize()+" "+name5.capitalize() +" "+ name6.capitalize()+" "+name7.capitalize()+" "+name8.capitalize()) 


# In[ ]:




