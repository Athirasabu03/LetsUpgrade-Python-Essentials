#!/usr/bin/env python
# coding: utf-8

# In[1]:


test_list = [1, 1, 5, 8, 10,77,56] 
sub_list = [1,1,5] 
  
# printing original lists 
print ("Original list : " + str(test_list)) 
print ("Original sub list : " + str(sub_list)) 
  
# using issubset() to  
# check subset of list  
flag = 0
if(set(sub_list).issubset(set(test_list))): 
    flag = 1
      
# printing result 
if (flag) : 
    print ("It's a match") 
else : 
    print ("It's Gone") 


# In[ ]:




