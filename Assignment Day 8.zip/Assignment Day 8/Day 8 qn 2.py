#!/usr/bin/env python
# coding: utf-8

# In[1]:


file1 = open("basic.txt") 
# Reading from file 
print(file1.read()) 
  
file1.close() 


# In[2]:


file1 = open("basic.txt", "a") 
  
# Writing to file 
file1.write("Writing to file :)") 
  
# Closing file 
file1.close() 


# In[ ]:





# In[4]:


"Hello"


# In[ ]:




