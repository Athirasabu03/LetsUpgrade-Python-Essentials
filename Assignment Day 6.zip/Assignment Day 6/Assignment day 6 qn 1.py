#!/usr/bin/env python
# coding: utf-8

# In[5]:


class Bank_Account: 
    def __init__(self):
        self.name="Athira"
        self.balance=0
 
  
    def deposit(self): 
        amount=float(input("Enter amount to be Deposited: ")) 
        self.balance += amount 
        print(" Amount Deposited:",amount) 
  
    def withdraw(self): 
        amount = float(input("Enter amount to be Withdrawn: ")) 
        if self.balance>=amount: 
            self.balance-=amount 
            print("You Withdrew:", amount) 
        else: 
            print(" Insufficient balance  ") 
  
   
  

# creating an object of class 
s = Bank_Account() 
   
# Calling functions with that class object 
s.deposit() 
s.withdraw() 
 


# In[ ]:





# In[ ]:




