#!/usr/bin/env python
# coding: utf-8

# In[5]:


import math
 
    pi=math.pi
class cone:
    def __init__(self,radius,height):
self.radius = float(input('Please Enter the Radius of a Cone: '))
self.height = float(input('Please Enter the Height of a Cone: '))

def Volume(self):
    V = (1.0/3) * math.pi * radius * radius * height
    print(" The Volume of a Cone = %.2f" %)
    
def Surface_Area(self):
    S= math.pi * radius * (radius + l)
    print(" The Surface Area of a Cone = %.2f " %S)




# In[ ]:





# In[ ]:




